<div class="<?php print $classes; ?>"<?php print $attributes; ?>>
  
  <div class="image">
    <?php print render($content['field_slider_image']); ?>
  </div>

  <div class="description">
    <?php print render($content['field_slider_title']); ?>
    <?php print render($content['field_slider_body']); ?>
  </div>

  <div class="background-image"></div>

</div>
